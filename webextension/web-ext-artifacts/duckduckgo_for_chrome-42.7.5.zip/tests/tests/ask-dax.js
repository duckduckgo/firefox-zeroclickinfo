(function() {
    test("Some unit test", function() {
        ok(1 === 1);
    });

    test("Another unit test", function() {
        ok(1 === 1);
    });
})();
